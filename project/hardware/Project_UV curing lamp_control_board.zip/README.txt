紫外线固化灯波长395mm，单个led功率
3W，3.4-3.7V 700MA
5W，3.4-3.6V 1300MA            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。